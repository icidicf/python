#!/usr/bin/bash

rm latest_compiled_at*
startname="latest_compiled_at-"`date +%Y-%b-%d-%H:%M:%S`

touch $startname
