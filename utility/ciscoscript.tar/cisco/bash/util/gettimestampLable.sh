#!/usr/bin/bash

str="MCP_DEV_LB_NIGHTLY_"`date +%Y%m%d_%H%M%S`
echo $str
